
DROP DATABASE IF EXISTS olimpia;
CREATE DATABASE olimpia;
USE olimpia;

-- betöltési sorrend
--   orszagok
--   erem_tabla
--   versenyzok
--   csapattagok
--   sportagak
--   versenyszamok
--   eredmenyek
